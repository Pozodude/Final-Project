import pyttsx3  # For text-to-speech
import os
from binary_tree import BST


# Load NATO alphabet from file
def load_nato_alphabet(file_path):
    nato_alphabet = {}
    try:
        with open(file_path, 'r') as file:
            for line in file:
                parts = line.strip().split()
                if len(parts) >= 2:
                    char = parts[0]
                    code = ' '.join(parts[1:])
                    nato_alphabet[char] = code
    except FileNotFoundError:
        print(f"Error: The file {file_path} was not found.")
    return nato_alphabet


# Create BST from NATO alphabet
def create_bst(nato_alphabet):
    bst = BST()
    for char, code in nato_alphabet.items():
        bst.insert(code, char)
    return bst

def load_nato_alphabet_and_create_bst(file_path):
    nato_alphabet = {}
    bst = BST()
    try:
        with open(file_path, 'r') as file:
            for line in file:
                parts = line.strip().split()
                if len(parts) >= 2:
                    char = parts[0]
                    code = ' '.join(parts[1:])
                    nato_alphabet[char] = code
                    bst.insert(char.upper(), code)
    except FileNotFoundError:
        print(f"Error: The file {file_path} was not found.")
    return bst

# Function to encode text using BST
def encode_text(text, bst):
    return ' '.join(bst.search(char.upper()) or '' for char in text)

# Function to decode text using BST
def decode_text(text, bst):
    return ''.join(bst.search(code) or '' for code in text.split())


# Initialize text-to-speech engine
engine = pyttsx3.init()


def read_aloud(text):
    engine.say(text)
    engine.runAndWait()

def save_choice(text):
    output_file = 'output.txt'
    print("Would you like to save this text?")
    choice = input("Enter your choice: ")
    choice.strip()
    choice.lower()
    if "yes" == choice or "y" == choice:
        with open(output_file, 'a') as f:
            f.write(text)
            f.write("\n")
            f.close()
        print(f"Encoded text saved to '{output_file}'.")

def read_choice(text):
    print("Would you like to read this text aloud?")
    choice = input("Enter your choice: ")
    choice.strip()
    choice.lower()
    if "yes" == choice or "y" == choice:
        print('Reading text')
        engine.say(text)
        engine.runAndWait()
    return
def main():
    # Load NATO alphabet from file
    nato_file = 'nato_alphabet.txt'
    nato_alphabet = load_nato_alphabet(nato_file)
    if not nato_alphabet:
        print("Failed to load NATO alphabet.")
        return

    # Create BST for decoding
    bst = create_bst(nato_alphabet)
    # Create BST for encoding
    bst2 = load_nato_alphabet_and_create_bst(nato_file)
    # Load content from file
    input_file = 'output.txt'
    output_file = 'output.txt'


    # Menu
    while True:
        print("\nChoose an option:")
        print("1. Encode text")
        print("2. Decode text")
        print("3. Read aloud")
        print("4. Read saved file")
        print("5. Exit")

        choice = input("Enter your choice: ")

        if choice == '1':
            text = input("Enter text to encode: ")

            encoded = encode_text(text, bst2)

            if text.isalpha():
                print("Encoded text:", encoded)
                read_choice(encoded)
                save_choice(encoded)
            else:
                print("Invalid NATO code.")
                text = input("Enter text to encode: ")
                encoded = encode_text(text, bst2)
                print("Encoded text:", encoded)
                read_choice(encoded)
                save_choice(encoded)



        elif choice == '2':
            text = input("Enter NATO encoded text to decode: ")
            decoded = decode_text(text, bst)
            if decoded:
                print("Decoded text:", decoded)
                read_choice(decoded)
                save_choice(decoded)
            else:
                print("Invalid NATO code.")

        elif choice == '3':
            text = input("Enter text to read aloud: ")
            read_aloud(text)

        elif choice == '4':
            if os.path.exists(input_file):
                with open(input_file, 'r') as f:
                    file_content = f.read()
                print("File content:")
                print(file_content)
            else:
                print(f"No file found with the name '{input_file}'.")
                file_content = ''


        elif choice == '5':
            print("Exiting...")
            break

        else:
            print("Invalid choice, please try again.")


if __name__ == "__main__":
    main()

